package com.example.tm470talkingcash;

import static org.junit.Assert.*;

import org.junit.Test;

public class PostCreationActivityTest {

    @Test
    public void onCreate() {
    }

    @Test
    public void onCreateOptionsMenu() {
    }

    @Test
    public void onOptionsItemSelected() {
    }
}