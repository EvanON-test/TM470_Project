package com.example.tm470talkingcash;

import static org.junit.Assert.*;

import org.junit.Test;

public class MainThreadActivityTest {

    @Test
    public void onCreate() {
    }

    @Test
    public void onStart() {
    }

    @Test
    public void onStop() {
    }

    @Test
    public void onCreateOptionsMenu() {
    }

    @Test
    public void onOptionsItemSelected() {
    }
}