package com.example.tm470talkingcash;

import static org.junit.Assert.*;

import org.junit.Test;

public class CommentViewHolderTest {

    @Test
    public void bindPost() {
    }
}