package com.example.tm470talkingcash;

import static org.junit.Assert.*;

import org.junit.Test;

public class GdprActivityTest {

    @Test
    public void onCreate() {
    }
}