package com.example.tm470talkingcash;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class GdprActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gdpr);
        //TODO: create a template GDPR
    }
}