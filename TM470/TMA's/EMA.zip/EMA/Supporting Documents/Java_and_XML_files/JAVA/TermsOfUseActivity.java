package com.example.tm470talkingcash;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class TermsOfUseActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_terms_of_use);
    }
}