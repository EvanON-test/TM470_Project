package com.example.tm470talkingcash;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class LegalDisclaimerActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_legal_disclaimer);

        //TODO: create a template Legal disclaimer
    }
}